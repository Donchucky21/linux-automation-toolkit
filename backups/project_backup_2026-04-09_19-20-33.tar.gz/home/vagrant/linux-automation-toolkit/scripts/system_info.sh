#! /bin/bash

#This script runs some system information

echo "Hostname is: $HOSTNAME"
echo "Date is: $(date)"
echo "CPU is: $(lscpu)"
echo "Ram is: $(free -h)"
echo "Disk usage is: $(df -h)"
ip a